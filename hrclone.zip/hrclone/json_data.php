<?php 


require('dbconnect.php');
header('Access-Control-Allow-Origin: *');

$sql = "SELECT * FROM employee ORDER by id ASC";
$result = $conn->query($sql);

$arrResp=array();
if ($result->num_rows > 0) {

  $data = mysqli_fetch_all($result,MYSQLI_ASSOC);
  $arrResp=$data;
 // $arrResp=array("staus"=>1,"message"=>"success","data"=>$data);/
}else{
	$arrResp=array("staus"=>0,"message"=>"No data found!");
}

//print_r($arrResp);
echo json_encode($arrResp);




?>