<?php 


require('dbconnect.php');


if($_POST['id']==0){

	$sql = "SELECT * FROM employee where emp_code='".$_POST['emp_code']."'";
	$result = $conn->query($sql);

	if ($result->num_rows == 0) {

	$sql = "INSERT INTO employee (emp_code,name,department,gender,dob,joining_date,prev_experience,salary,address)
	VALUES ('".$_POST['emp_code']."','".$_POST['name']."','".$_POST['department']."','".$_POST['gender']."','".date('Y-m-d',strtotime($_POST['dob']))."','".date('Y-m-d',strtotime($_POST['joining_date']))."','".$_POST['prev_experience']."',".$_POST['salary'].",'".$_POST['address']."')";

	if ($conn->query($sql) === TRUE) {
	  echo "New record created successfully.  <a href='index.php'>Go to Index Page.</a>";
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	}

	}else{
		echo "Record already exist with same emp code.";
	}

}else{


	$sql = "SELECT * FROM employee where emp_code='".$_POST['emp_code']."' AND id !='".$_POST['id']."'";
	$result = $conn->query($sql);

	if ($result->num_rows == 0) {

	$sql = "UPDATE employee SET emp_code='".$_POST['emp_code']."',name='".$_POST['name']."',department='".$_POST['department']."',gender='".$_POST['gender']."',dob='".date('Y-m-d',strtotime($_POST['dob']))."',joining_date='".date('Y-m-d',strtotime($_POST['joining_date']))."',prev_experience='".$_POST['prev_experience']."',salary=".$_POST['salary'].",address='".$_POST['address']."' WHERE id='".$_POST['id']."'";


	if ($conn->query($sql) === TRUE) {
	  echo "Record updated successfully. <a href='index.php'>Go to Index Page.</a>";
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	}

	}else{
		echo "Record already exist with same emp code.";
	}
}

/*$conn->close();*/



?>