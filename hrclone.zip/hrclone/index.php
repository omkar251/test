<!DOCTYPE html>
<html>
<head>
  <title>HR Clone</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" >
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<style type="text/css">
  table, td, th {
  border: 1px solid black;
}


table {
  border-collapse: collapse;
}
</style>
</head>

<body>
<div class="container">
<?php require('dbconnect.php'); ?>

  <?php  

  if(isset($_GET['id'])){

    $id=$_GET['id'];

    $sql = "SELECT * FROM employee where id='".$id."'";
    $result = $conn->query($sql);

    if ($result->num_rows >0) {

        $empData= $result->fetch_assoc();
        

    }else{
      echo "No data found!";
      exit;
    }
  }





  ?>
  <div class="row" style="padding-top: 20px; max-width: 50%">
    <div class="col-md-12">
  <form method="post" action="dbdata.php">

    <input type="hidden" name="id" value="<?php if(isset($empData['id'])){echo $empData['id']; }else{echo "0"; }?>">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Emp Cpde</label>
      <input type="text" class="form-control" id="emp_code" name="emp_code" value="<?php if(isset($empData['emp_code'])){echo $empData['emp_code']; }?>" placeholder="Enter emp code">
    </div>
   
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Name</label>
      <input type="text" class="form-control" id="name" name="name" value="<?php if(isset($empData['name'])){echo $empData['name']; }?>" placeholder="Enter name">
    </div>
   
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Department</label>
      <select class="form-select" aria-label="" name="department" id="department">
        <option disabled selected="">Select Department</option>
        <option value="Admin">Admin</option>
        <option value="Technology">Technology</option>
        <option value="Accounts">Accounts</option>
      </select>
    </div>
   
  </div>
  <div class="form-group">
    <label for="inputAddress">Gender</label>
    <div class="form-check">
  <input type="radio" class="form-check-input" id="male" name="gender" value="Male" <?php if(isset($empData['gender'])&&$empData['gender']=="Male"){echo "checked"; }?>>Male
  <label class="form-check-label" for="radio1"></label>
</div>
<div class="form-check">
  <input type="radio" class="form-check-input" id="female" name="gender" value="Female" <?php if(isset($empData['gender'])&&$empData['gender']=="Female"){echo "checked"; }?>>Female
  <label class="form-check-label" for="radio2"></label>
</div>
<div class="form-check">
  <input type="radio" class="form-check-input" id="other" name="gender" value="Other" <?php if(isset($empData['gender'])&&$empData['gender']=="Other"){echo "checked"; }?>>Other
  <label class="form-check-label"></label>
</div>
  </div>

  <div class="form-group">
    <label for="inputAddress2">DOB</label>
    <input type="date" class="form-control" id="dob" name="dob" value="<?php if(isset($empData['dob'])){echo $empData['dob']; }?>" placeholder="Enter DOB">
  </div>

   <div class="form-group">
    <label for="joining_date">Joining Date</label>
    <input type="date" class="form-control" id="joining_date" name="joining_date" value="<?php if(isset($empData['joining_date'])){echo $empData['joining_date']; }?>"  placeholder="Enter joining date">
  </div>

   <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Prev Experience</label>
      <input type="text" class="form-control" id="prev_experience" name="prev_experience" value="<?php if(isset($empData['prev_experience'])){echo $empData['prev_experience']; }?>" placeholder="Enter prev exp.">
    </div>
   
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Salary</label>
      <input type="number" class="form-control" id="salary" name="salary" placeholder="Enter salary" value="<?php if(isset($empData['salary'])){echo $empData['salary']; }?>">
    </div>
   
  </div>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">Address</label>
      <textarea class="form-control"  name="address" maxlength="150" rows="3"><?php if(isset($empData['address'])){echo $empData['address']; }?></textarea>
    </div>
    </div>
    <br>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>

<script type="text/javascript">


 document.getElementById('department').value = '<?php if(isset($empData['department'])){echo $empData['department']; }?>';
</script>
  
  <div class="row" style="padding: 20px; ">
    <div class="col-md-12">
      <table class="table">
        <thead>
          <tr>
            <th>Emp Code</th>
            <th>Name</th>
            <th>Department</th>
            <th>Gender</th>
            <th>DOB</th>
            <th>Joining Date</th>
            <th>Prev Experience</th>
            <th>Salary</th>
            <th>Address</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
<?php 

$sql = "SELECT * FROM employee ORDER by id ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    //echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";


    echo " <tr>
            <td>". $row["emp_code"]. "</td>
            <td>". $row["name"]. "</td>
            <td>". $row["department"]. "</td>
            <td>". $row["gender"]. "</td>
            <td>". $row["dob"]. "</td>
            <td>". $row["joining_date"]. "</td>
            <td>". $row["prev_experience"]. "</td>
            <td>". $row["salary"]. "</td>
            <td>". $row["address"]. "</td>
            <td><a href='index.php?id=". $row["id"]. "'>EDIT</a></td>
          </tr>";
  }

} else {
  echo " <tr>
            <td colspan='10'>No data found!</td>
            
          </tr>";
}

?>

         
        </tbody>
      </table>
    </div>
  </div>


   </div>
</body>
</html>